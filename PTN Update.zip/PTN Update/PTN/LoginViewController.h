//
//  LoginViewController.h
//  PTN
//
//  Created by Juan Gerardo on 11/20/16.
//  Copyright © 2016 iFoundry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController

@end


/*
    titleLabel: UILabel
    userNameLabel: UILabel
    password: UILabel
    userNameTextField: UITextField
    passwordTextField: UITextField
    goButton: UIButton
 
    -(IBAction)goButtonPressed:(UIButton*)sender
*/
